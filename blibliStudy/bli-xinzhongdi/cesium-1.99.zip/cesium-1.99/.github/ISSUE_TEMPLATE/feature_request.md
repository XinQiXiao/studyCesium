---
name: Request a feature
about: New ideas & improvements to Cesium are always welcome.
---

<!--
Thanks for helping make Cesium better!

When suggesting an idea, give examples of the intended use case. Features that benefit the wider community are more likely to be prioritized.

The best way to get your ideas into Cesium is to help us! We love contributions and are always happy to be provide feedback and advice. Check out the contributor guide to get started:

https://github.com/CesiumGS/cesium/blob/main/CONTRIBUTING.md
-->
